export interface ProcedureResponse {
  id ?: number;
  description: string;
}
