export interface EmployeeResponse {
  id?: number;
  names: string;
  surnames: string;
}
