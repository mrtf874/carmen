export interface ContactFormResponse {
  description: string;
  id: number;
}
