export interface CountryResponse {
  description: string;
  mobile_code: string;
  id: number;
}
