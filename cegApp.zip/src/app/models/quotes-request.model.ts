export class QuotesRequest {
  client_id?: number;
  date: string;
  employee_id: number;
  notes: string;
  procedure_id: number;
  picture_before: string;
  picture_after: string;
  id?: number;
}
