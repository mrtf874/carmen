import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'ceg-footer',
  templateUrl: './footer.component.html',
  styleUrls: ['./footer.component.css']
})

/**
 * @author Jhon Alexander López Bohórquez
 */
export class FooterComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
