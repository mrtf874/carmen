module.exports = {
  output: {
    jsonpFunction: 'ceg-element',
    library: 'cegelement'
  }
};
